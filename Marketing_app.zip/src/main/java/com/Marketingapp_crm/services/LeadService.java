package com.Marketingapp_crm.services;

import com.Marketingapp_crm.entities.Lead;

public interface LeadService {

	public void saveLeadData(Lead lead);
	
}
