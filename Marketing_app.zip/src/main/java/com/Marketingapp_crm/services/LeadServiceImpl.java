package com.Marketingapp_crm.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Marketingapp_crm.entities.Lead;
import com.Marketingapp_crm.repositories.LeadRepository;

@Service
public class LeadServiceImpl implements LeadService {

	@Autowired
	private LeadRepository leadRepo;
	
	@Override
	public void saveLeadData(Lead lead) {
		leadRepo.save(lead);
		
	}
	

}
