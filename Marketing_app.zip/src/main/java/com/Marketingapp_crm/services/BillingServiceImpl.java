package com.Marketingapp_crm.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Marketingapp_crm.entities.Billing;
import com.Marketingapp_crm.repositories.BillingRepository;
@Service
public class BillingServiceImpl implements BillingService {

	@Autowired
	private BillingRepository billingRepo;
	@Override
	public void saveBillingData(Billing billing) {
		billingRepo.save(billing);

	}

}
