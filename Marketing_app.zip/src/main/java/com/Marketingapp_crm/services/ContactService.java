package com.Marketingapp_crm.services;

import com.Marketingapp_crm.entities.Contacts;

public interface ContactService {
	public void saveContactData(Contacts contact);

}
