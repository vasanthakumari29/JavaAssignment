package com.Marketingapp_crm.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Marketingapp_crm.entities.Contacts;
import com.Marketingapp_crm.repositories.ContactRepository;

@Service
public class ContactServiceImpl implements ContactService {

	@Autowired
	ContactRepository contactRepo;
	@Override
	public void saveContactData(Contacts contact) {
		contactRepo.save(contact);
	}

}
