package com.Marketingapp_crm.services;

import com.Marketingapp_crm.entities.Billing;

public interface BillingService {

	public void saveBillingData(Billing billing);
}
