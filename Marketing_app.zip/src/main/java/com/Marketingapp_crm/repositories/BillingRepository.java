package com.Marketingapp_crm.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Marketingapp_crm.entities.Billing;

public interface BillingRepository extends JpaRepository<Billing, Long> {

}
