package com.Marketingapp_crm.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Marketingapp_crm.entities.Contacts;

public interface ContactRepository extends JpaRepository<Contacts, Long> {

}
