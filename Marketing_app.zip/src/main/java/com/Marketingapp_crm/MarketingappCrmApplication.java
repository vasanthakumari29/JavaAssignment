package com.Marketingapp_crm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarketingappCrmApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarketingappCrmApplication.class, args);
	}

}
