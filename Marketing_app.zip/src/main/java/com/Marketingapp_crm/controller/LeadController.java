package com.Marketingapp_crm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Marketingapp_crm.entities.Billing;
import com.Marketingapp_crm.entities.Contacts;
import com.Marketingapp_crm.entities.Lead;
import com.Marketingapp_crm.services.BillingService;
import com.Marketingapp_crm.services.ContactService;
import com.Marketingapp_crm.services.LeadService;


@Controller
public class LeadController {
	@Autowired
	private LeadService leadService;
	
	@Autowired
	private ContactService contactService;
	
	@Autowired
	private BillingService billingService;
	
	
	@RequestMapping("/newlead")
	public String newlead() {
		
		return "newlead";
	}
	
	@RequestMapping("/savelead")
	public String savelead(Lead lead ) {
		
		leadService.saveLeadData(lead);
		
		return "newlead";
	}
	
	@RequestMapping("/newcontact")
	public String contacts() {
		
		return "contacts";
	}

	@RequestMapping("/savecontact")
	public String savecontact(Contacts contact) {
		contactService.saveContactData(contact);
		
		return "contacts";
		
	}
	
	@RequestMapping("/billing")
	public String billing() {
		return "billing";
	}
	
	@RequestMapping("/savebilling")
	public String savebilling(Billing billing) {
		billingService.saveBillingData(billing);
		
		return "billing";
		
	}
	

}
