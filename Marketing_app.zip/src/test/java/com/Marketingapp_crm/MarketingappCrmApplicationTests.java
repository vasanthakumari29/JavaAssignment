package com.Marketingapp_crm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarketingappCrmApplicationTests {

	@Test
	void contextLoads() {
	}

}
