package com.App_redbus.contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.App_redbus.entity.User;
import com.App_redbus.repository.UserRepository;

@Controller
public class UserController {
	@Autowired
	private UserRepository userRepo;
	
	@RequestMapping("/show")
	public String show() {         /// http://localhost:8080/show
		return "show";
	}
	
	@RequestMapping("/saveUserDetails")
	public String saveUserDetails(@ModelAttribute("user") User user,ModelMap model) {
		userRepo.save(user);
		model.addAttribute("user",user);
		
		return "displaydetails";
		
		
	}
}
