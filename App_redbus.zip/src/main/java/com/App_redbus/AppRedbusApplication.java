package com.App_redbus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppRedbusApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppRedbusApplication.class, args);
	}

}
