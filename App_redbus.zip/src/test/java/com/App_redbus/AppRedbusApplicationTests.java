package com.App_redbus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppRedbusApplicationTests {

	@Test
	void contextLoads() {
	}

}
